var crypto = require('crypto')
var abc = crypto.createHash('sha1').update('abc').digest('hex')
console.log(abc)
//require('hello').inlineCall().call2()
