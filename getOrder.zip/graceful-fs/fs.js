module.exports = require('natives').require('fs', ['stream'])
