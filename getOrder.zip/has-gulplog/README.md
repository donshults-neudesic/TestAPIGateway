# has-gulplog
Check if gulplog is available before attempting to use it
